The following is a list of contributors to the [clap](https://github.com/kbknapp/clap-rs) project, in alphabetical order:

 * [Alexander Kuvaev](https://github.com/Vinatorul) <<alexander@kuvaev.me>>
 * [Alex Gulyás](https://github.com/alex-gulyas)
 * [Dabo Ross](https://github.com/daboross) <<daboross@daboross.net>>
 * [Georg Brandl](https://github.com/birkenfeld) <<georg@python.org>>
 * [grossws](https://github.com/grossws)
 * [Ivan Dmitrievsky](https://github.com/idmit) <<ivan.dmitrievsky@gmail.com>>
 * [Homu](https://github.com/homu)
 * [Huon Wilson](https://github.com/huonw)
 * [J/A](https://github.com/archer884)
 * [Jacob Helwig](https://github.com/jhelwig) <<jacob@technosorcery.net>>
 * [James McGlashan](https://github.com/james-darkfox)
 * [Kevin K.](https://github.com/kbknapp) <<kbknapp@gmail.com>>
 * [Markus Unterwaditzer](https://github.com/untitaker) <<markus@Unterwaditzer.net>>
 * [Nelson Chen](https://github.com/nelsonjchen)
 * [Sebastian Thiel](https://github.com/Byron) <<byronimo@gmail.com>>
 * [Severen Redwood](https://github.com/SShrike) <<severen.redwood@gmail.com>>
 * [SungRim Huh](https://github.com/sru) <<sungrimhuh@gmail.com>>
 * [Tshepang Lekhonkhobe](https://github.com/tshepang) <<Tshepang@gmail.com>>
 * [Vincent Prouillet](https://github.com/Keats)
 * [Vlad](https://github.com/N-006)
 * [Yo-Bot](https://github.com/yo-bot)
