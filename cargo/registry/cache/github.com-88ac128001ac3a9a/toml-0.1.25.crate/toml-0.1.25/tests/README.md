Tests are from https://github.com/BurntSushi/toml-test
