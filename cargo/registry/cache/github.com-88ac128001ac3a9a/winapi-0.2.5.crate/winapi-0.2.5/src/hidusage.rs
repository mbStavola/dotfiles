// Copyright © 2015, Alex Daniel Jones
// Licensed under the MIT License <LICENSE.md>
// Taken from hidusage.h
pub type USAGE = ::USHORT;
pub type PUSAGE = *mut USAGE;
