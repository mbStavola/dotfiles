// Copyright © 2015, Peter Atashian
// Licensed under the MIT License <LICENSE.md>
pub type LPUINT = *mut ::c_uint;
