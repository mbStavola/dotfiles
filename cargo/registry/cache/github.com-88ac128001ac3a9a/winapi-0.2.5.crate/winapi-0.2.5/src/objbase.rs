//! Component object model defintions
pub const COINIT_APARTMENTTHREADED: ::DWORD = 0x2;
pub const COINIT_MULTITHREADED: ::DWORD = 0x0;
pub const COINIT_DISABLE_OLE1DDE: ::DWORD = 0x4;
pub const COINIT_SPEED_OVER_MEMORY: ::DWORD = 0x8;
