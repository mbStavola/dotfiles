// Copyright © 2015, Peter Atashian
// Licensed under the MIT License <LICENSE.md>
// STUB
DECLARE_HANDLE!(HDROP, HDROP__);
